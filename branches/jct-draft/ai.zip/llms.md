# ihe.pharm.meow#0.1.0: IHE Pharmacy Medication Overview

## Pages

* [MeOw Home](index.md)
* [Volume 1 Overview](volume1.md)
* [Security Considerations](security_considerations.md)
* [Use Case overview](usecases.md)
* [Cross Profile Considerations](cross_profile_considerations.md)
* [Medication Treatment Lifecycle](medication_treatment_lifecycle.md)
* [Use Case 1 - ...](usecase-1.md)
* [Glossary](glossary.md)
* [PHARM-12 Query Medication Resources](PHARM-12.md)
* [Actor Options](actor_options.md)
* [Volume 2: Transactions](volume2.md)
* [Actors and Transactions](actors-transactions.md)
* [Artifacts Summary](artifacts.md)
* [Data Models](data_models.md)
* [Actor Required Grouping](actor_required_grouping.md)
* [Aggregation and Medication Reconcilliation](aggregation_and_medication_reconcilliation.md)
* [PHARM-11 Retrieve Medication Overview](PHARM-11.md)
* [Medication Concepts](medication_concepts.md)
* [Issues](issues.md)

## Resources

### CodeSystems

* [Clinical Intent Type CodeSystem](CodeSystem-ihe-cs-clinicalintenttype.md)

### ValueSets

* [Clinical Intent Type ValueSet](ValueSet-ihe-vs-clinicalintenttype.md)

### Logicals

* [Dosaging (model)](StructureDefinition-DosagingInformation.md)
* [Medication Overview (model)](StructureDefinition-MedicationOverviewLM.md)
* [Medication Treatment (model)](StructureDefinition-MedicationTreatmentLM.md)
* [Medication Treatment Line (model)](StructureDefinition-MedicationTreatmentLineLM.md)
* [Medicinal product (model)](StructureDefinition-MedicinalProductLM.md)
* [Patient (model)](StructureDefinition-PatientLM.md)
* [Practitioner (model)](StructureDefinition-PractitionerLM.md)

### Resource Profiles

* [Medicinal product](StructureDefinition-IHEMedication.md)
* [Medication Overview Bundle](StructureDefinition-MedicationOverview.md)
* [Medication Overview Composition](StructureDefinition-MedicationOverviewComposition.md)
* [Medication Treatment](StructureDefinition-MedicationTreatment.md)
* [Medication Treatment Line](StructureDefinition-MedicationTreatmentLine.md)

### Extensions

* [Medication - Classification](StructureDefinition-ihe-ext-medication-classification.md)
* [Medication - Device](StructureDefinition-ihe-ext-medication-device.md)
* [Medication - Product Name](StructureDefinition-ihe-ext-medication-productname.md)
* [Medication - Size of Item](StructureDefinition-ihe-ext-medication-sizeofitem.md)
* [MedicationStatement - Clinical Intent Type](StructureDefinition-ihe-ext-medicationstatement-clinicalintenttype.md)
* [MedicationStatement - Off-Label Use](StructureDefinition-ihe-ext-medicationstatement-offlabel.md)
* [MedicationStatement - Recorder](StructureDefinition-ihe-ext-medicationstatement-recorder.md)
* [MedicationStatement - Substitution](StructureDefinition-ihe-ext-medicationstatement-substitution.md)
* [MedicationStatement - Verification Information](StructureDefinition-ihe-ext-medicationstatement-verificationinformation.md)

### CapabilityStatements

* [Medication Overview Consumer](CapabilityStatement-MedicationOverviewConsumer.md)
* [Medication Overview Responder](CapabilityStatement-MedicationOverviewResponder.md)

### ImplementationGuides

* [IHE Pharmacy Medication Overview](index.md)

### Examples

* [01A-Cefuroxime1500GenericExplicit (Medication)](Medication-01A-Cefuroxime1500GenericExplicit.md)
* [01B-Cefuroxime1500GenericConcept (Medication)](Medication-01B-Cefuroxime1500GenericConcept.md)
* [01C-Cefuroxime1500Branded (Medication)](Medication-01C-Cefuroxime1500Branded.md)
* [02A-ClotrimazoleCanifugCremolum (Medication)](Medication-02A-ClotrimazoleCanifugCremolum.md)
* [02A1-CanifugCremolumCreamItem (Medication)](Medication-02A1-CanifugCremolumCreamItem.md)
* [02A2-CanifugCremolumPessaryItem (Medication)](Medication-02A2-CanifugCremolumPessaryItem.md)
* [03B-VitaminBComplexBranded (Medication)](Medication-03B-VitaminBComplexBranded.md)
