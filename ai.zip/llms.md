# ihe.pharm.meow#0.1.0: IHE Pharmacy Medication Overview

## Pages

* [MeOw Home](index.md)
* [Medication Concepts](medication_concepts.md)
* [Security Considerations](security_considerations.md)
* [Glossary](glossary.md)
* [Artifacts Summary](artifacts.md)
* [Volume 2](volume2.md)
* [PHARM yyy](PHARM-y.md)
* [Cross Profile Considerations](cross_profile_considerations.md)
* [Volume 1 Overview](volume1.md)
* [Use Case overview](usecases.md)
* [Medication Treatment Lifecycle](medication_treatment_lifecycle.md)
* [PHARM xxx](PHARM-x.md)
* [Issues](issues.md)
* [Data Models](data_models.md)
* [Aggregation and Medication Reconcilliation](aggregation_and_medication_reconcilliation.md)
* [Actors and Transactions](actors-transactions.md)
* [Actor Required Grouping](actor_required_grouping.md)
* [Actor Options](actor_options.md)
* [Use Case 1 - ...](usecase-1.md)

## Resources

### Logicals

* [Dosaging (model)](StructureDefinition-DosagingInformation.md)
* [Medication Overview (model)](StructureDefinition-MedicationOverviewLM.md)
* [Medication Treatment (model)](StructureDefinition-MedicationTreatmentLM.md)
* [Medication Treatment Line (model)](StructureDefinition-MedicationTreatmentLineLM.md)
* [Medicinal product (model)](StructureDefinition-MedicinalProductLM.md)
* [Patient (model)](StructureDefinition-PatientLM.md)
* [Practitioner (model)](StructureDefinition-PractitionerLM.md)

### Resource Profiles

* [Medicinal product](StructureDefinition-IHEMedication.md)
* [Medication Overview Bundle](StructureDefinition-MedicationOverview.md)
* [Medication Overview Composition](StructureDefinition-MedicationOverviewComposition.md)
* [Medication Treatment](StructureDefinition-MedicationTreatment.md)
* [Medication Treatment Line](StructureDefinition-MedicationTreatmentLine.md)

### Extensions

* [Medication - Classification](StructureDefinition-ihe-ext-medication-classification.md)
* [Medication - Device](StructureDefinition-ihe-ext-medication-device.md)
* [Medication - Product Name](StructureDefinition-ihe-ext-medication-productname.md)
* [Medication - Size of Item](StructureDefinition-ihe-ext-medication-sizeofitem.md)
* [MedicationStatement - Substitution](StructureDefinition-ihe-ext-medicationstatement-substitution.md)
* [MedicationStatement - Verification Information](StructureDefinition-ihe-ext-medicationstatement-verificationinformation.md)

### ImplementationGuides

* [IHE Pharmacy Medication Overview](index.md)

### Examples

* [01A-Cefuroxime1500GenericExplicit (Medication)](Medication-01A-Cefuroxime1500GenericExplicit.md)
* [01B-Cefuroxime1500GenericConcept (Medication)](Medication-01B-Cefuroxime1500GenericConcept.md)
* [01C-Cefuroxime1500Branded (Medication)](Medication-01C-Cefuroxime1500Branded.md)
* [02A-ClotrimazoleCanifugCremolum (Medication)](Medication-02A-ClotrimazoleCanifugCremolum.md)
* [02A1-CanifugCremolumCreamItem (Medication)](Medication-02A1-CanifugCremolumCreamItem.md)
* [02A2-CanifugCremolumPessaryItem (Medication)](Medication-02A2-CanifugCremolumPessaryItem.md)
* [03B-VitaminBComplexBranded (Medication)](Medication-03B-VitaminBComplexBranded.md)
