
1. how to identify drugs and different granularities (from dispense to presc to MTL)
2. OTC should be considered to MTL?
3. examples and profiles check
4. ...


please see also [here](https://github.com/IHE/pharm-meow/issues)